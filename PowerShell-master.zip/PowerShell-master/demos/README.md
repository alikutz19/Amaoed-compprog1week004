This folder contains demos primarily targeted for Linux systems.
Each demo showcases how to use PowerShell to be more productive by
leveraging objects and how it can integrate with existing Linux 
scripts and/or commands.
